-- AlterTable
ALTER TABLE "BillPayment" ADD COLUMN     "currency" TEXT NOT NULL DEFAULT 'INR';
